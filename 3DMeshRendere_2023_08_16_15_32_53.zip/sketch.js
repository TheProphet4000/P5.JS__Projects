let angleY = 0;
let angleX = 0;
let angleZ = 0;
let speed = 0;
let mesh;
let tex;

function setup() {
  createCanvas(400, 400, WEBGL);
  mesh = loadModel("Door.obj", true);
  tex = loadImage("DoorTex.jpg");
}

function draw() {
  RotateAndRender();
}

function RotateAndRender() {
  background(220);
  orbitControl();
  rotX();
  rotY();
  rotZ();
  applyRot();
  strokeWeight(0);
  texture(tex); //loads texture
  model(mesh); // loads model
} //This controlls Rotation and rendering of the model

function applyRot() {
  speed = 1; //this sets automatic rotation
  angleX += 0;
  angleY += 0.001;
  angleZ += 0;
} //This is a plugboard with setters CHANGE SPEED AND ROTATION HERE

//No touch-------
function rotX() {
  rotateX((angleX *= speed));
} //sets rotation on the x axis
function rotY() {
  rotateY((angleY *= speed));
} //sets rotation on the y axis
function rotZ() {
  rotateZ((angleZ *= speed));
} //sets rotation on the z axis
//--------------
